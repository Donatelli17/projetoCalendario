import React from 'react'
import './Cabecalho.css'

export default function Cabecalho() {
    return (
        <div className="Cabecalho">
            <h1>Cabecalho</h1>
        </div>
    )
}
